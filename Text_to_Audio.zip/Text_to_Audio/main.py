from gtts import gTTS
import pdfplumber
from pathlib import Path
import os
import docx2txt
import langid


def pdf_to_audio(file_path='./', language='en', speed=False):
    if Path(file_path).is_file() and Path(file_path).suffix == '.pdf':
        print(f'[!] {Path(file_path).stem} is processing...')
        with pdfplumber.PDF(open(file=file_path, mode='rb')) as pdf:
            pages = [pages.extract_text() for pages in pdf.pages]
        doc_text = ''.join(pages).replace('\n', '')
        lang = langid.classify(doc_text)
        audio = gTTS(doc_text, lang=lang[0], slow=speed)
        file_name = Path(file_path).stem
        audio.save(f'files/{file_name}.mp3')
        os.remove(file_path)
        return print(f'[+] {file_name} has been converted to audio!')

    elif Path(file_path).is_file() and Path(file_path).suffix == '.docx':
        print(f'[!] {Path(file_path).stem} is processing...')
        doc_text = str(docx2txt.process(file_path)).replace('\n', '')
        lang = langid.classify(doc_text)
        audio = gTTS(doc_text, lang=lang[0], slow=speed)
        file_name = Path(file_path).stem
        audio.save(f'files/{file_name}.mp3')
        os.remove(file_path)
        return print(f'[+] {file_name} has been converted to audio!')
    else:
        return print('[!] File not found')

if __name__ == "__main__":
    pdf_to_audio('./test.pdf')
