from flask import *
from werkzeug import *
from main import *

application = Flask(__name__)

@application.route('/home')
@application.route('/')
@application.route('/main')
@application.route('/main_page')
def home():
    return render_template('main.html')

@application.route('/index')
def index():
    return render_template('index.html')

@application.route('/help')
@application.route('/guide')
@application.route('/instruction')
def guide():
    return render_template('guide.html')

@application.route('/settings')
def settings():
    return render_template('settings.html')

@application.route('/about')
def about():
    return render_template('about.html')

@application.route('/uploader')
def uploader():
    return render_template('uploader.html')

@application.route('/uploader', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        file = request.files['file']
        file.save(file.filename)
        print(file.filename)
        inputFile = (f'./{file.filename}')
        pdf_to_audio(inputFile)
        file_name = str(file.filename).split('.')
        return send_file(f'files/{file_name[0]}.mp3', as_attachment=True)


if __name__ == '__main__':
    application.run(debug=False)
